let visor = document.getElementById("btmVAT");   
let visor2 = document.getElementById("btmVAN");  

let historico = "";
let limpaProximoInput = false;



function adicionarDigito(numeroAtual, novoDigito) {
  if (numeroAtual.length >= MAX_DIGITOS) {
    return numeroAtual; 
  }
  return numeroAtual + novoDigito;
}

const MAX_DIGITOS = 10; // Definido o limite máximo de dígitos

// Função auxiliar para evitar estouro de texto e formatar números grandes
function formatarResultado(valor) {
  let stringValor = valor.toString();
  
  // Se for erro ou string, retorna direto
  if (isNaN(valor)) return valor;

  // Se o número for maior que o limite visual, converte para notação científica
  if (stringValor.replace('-', '').length > MAX_DIGITOS) {
    return Number(valor).toPrecision(6);
  }
  
  return stringValor;
}

const botoesNumeros = {
  "btm16": "0", "btm9": "1", "btm10": "2", "btm12": "3", "btm8": "4",
  "btm7": "5",  "btm4": "6", "btm0": "7",  "btm2": "8",  "btm3": "9"
};


Object.keys(botoesNumeros).forEach(id => {
  let el = document.getElementById(id);
  if (el) {
    el.addEventListener("click", () => adicionarNumero(botoesNumeros[id]));
  }
});


const botoesOperacoes = {
  "btm14": "+", "btm13": "-", "btm5": "x", "btm11": "÷"
};


Object.keys(botoesOperacoes).forEach(id => {
  let el = document.getElementById(id);
  if (el) {
    el.addEventListener("click", () => adicionarOperacao(botoesOperacoes[id]));
  }
});

function adicionarNumero(numero) {
  if (visor.innerText === "0" || limpaProximoInput) {
    visor.innerText = numero;
    limpaProximoInput = false;
  } else {
    visor.innerText += numero;
  }
}

function adicionarOperacao(operador) {
  historico += visor.innerText + " " + operador + " ";
  visor2.innerText = historico;
  limpaProximoInput = true;
}


document.getElementById("btm1").addEventListener("click", function() {
  visor.innerText = "0";
  visor2.innerText = "0";
  historico = "";
});


document.getElementById("btm15").addEventListener("click", function() {
  visor2.innerText = historico + visor.innerText;  


  let expressao = (historico + visor.innerText)
    .replace(/x/g, "*")
    .replace(/÷/g, "/");
  
  try {
    visor.innerText = eval(expressao);
  } catch (erro) {
    visor.innerText = "Erro";
  }
  
  historico = "";
  limpaProximoInput = true;
});


var RdnButton = document.getElementById('RdnBtn');
RdnButton.addEventListener('click', BodyColorRandom);

function BodyColorRandom(){
  const RdnColor = '#' + Math.floor(Math.random()*16777215).toString(16);
    document.querySelector('body').style.backgroundColor = RdnColor;
     setTimeout(BodyColorRandom,1);
}